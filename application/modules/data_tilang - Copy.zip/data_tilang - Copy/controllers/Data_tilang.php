<?php defined("BASEPATH") or exit("No direct script access allowed");

/**
 * Data_tilang Controller.
 */
class Data_tilang extends MY_Controller
{
    private $title;

    public function __construct()
    {
        parent::__construct();

        $this->title = "Isi Data Tilang";
    }

    /**
     * Index
     */
    public function index()
    {
    }

    /**
     * CRUD
     */
	public function crudData_tilang()
	{
		$crud = new grocery_CRUD();
		
		$crud->set_table("data_tilang");
		$crud->set_subject("Isi Data Tilang");

		// Show in
		$crud->add_fields(["nomor_tilang", "tanggal_sidang", "nama_lengkap", "foto", "kecamatan", "tanggal_pengambilan", "nomor_hp", "alamat", "barang_bukti", "status", "biaya antar", "denda tilang"]);
		$crud->edit_fields([""]);
		$crud->columns(["tilangid", "nomor_tilang", "tanggal_sidang", "nama_lengkap", "foto", "kecamatan", "tanggal_pengambilan", "nomor_hp", "alamat", "barang_bukti", "status", "biaya antar", "denda tilang"]);

		// Fields type
		$crud->field_type("tilangid", "integer");
		$crud->field_type("nomor_tilang", "string");
		$crud->field_type("tanggal_sidang", "date");
		$crud->field_type("nama_lengkap", "string");
		$crud->set_field_upload("foto", 'assets/uploads');
		$crud->set_relation("kecamatan", "data_kecamatan", "kecamatan");
		$crud->field_type("tanggal_pengambilan", "date");
		$crud->field_type("nomor_hp", "integer");
		$crud->unset_texteditor("alamat", 'full_text');
		$crud->field_type("alamat", "text");
		$crud->set_relation("barang_bukti", "data_bb", "nama_bb");
		$crud->field_type("status", "string");
		$crud->field_type("biaya antar", "string");
		$crud->field_type("denda tilang", "string");

		// Relation n-n

		// Validation
		$crud->set_rules("tilangid", "Tilangid", "required");
		$crud->set_rules("nomor_tilang", "Nomor tilang", "required");
		$crud->set_rules("tanggal_sidang", "Tanggal sidang", "required");
		$crud->set_rules("nama_lengkap", "Nama lengkap", "required");
		$crud->set_rules("foto", "Foto Surat Tilang", "required");
		$crud->set_rules("kecamatan", "Kecamatan", "required");
		$crud->set_rules("tanggal_pengambilan", "Tanggal pengambilan", "required");
		$crud->set_rules("nomor_hp", "Nomor hp", "required");
		$crud->set_rules("alamat", "Alamat", "required");
		$crud->set_rules("barang_bukti", "Barang bukti", "required");
		$crud->set_rules("status", "Status", "required");
		$crud->set_rules("biaya antar", "Biaya antar", "required");
		$crud->set_rules("denda tilang", "Denda tilang", "required");

		// Display As

		// Unset action
		$crud->unset_read();
		$crud->unset_edit();
		$crud->unset_delete();

		$data = (array) $crud->render();

		$this->layout->set_wrapper( 'grocery', $data,'page', false);

		$template_data['grocery_css'] = $data['css_files'];
		$template_data['grocery_js']  = $data['js_files'];
		$template_data["title"] = "Isi Data Tilang";
		$template_data["crumb"] = ["table" => ""];
		$this->layout->auth();
		$this->layout->render('admin', $template_data); // front - auth - admin
	}
}

/* End of file example.php */
/* Location: ./application/modules/data_tilang/controllers/Data_tilang.php */